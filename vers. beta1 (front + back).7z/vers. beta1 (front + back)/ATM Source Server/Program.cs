﻿using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ATM_Source_Server
{
    internal class Server
    {
        static IPAddress serverIP = IPAddress.Parse("127.0.0.1"); // IP адрес сервера
        static int serverPort = 30126; // Порт сервера
        static IPEndPoint serverEP = new IPEndPoint(serverIP, serverPort); // IPEndPoint сервера
        static public TcpListener server = new TcpListener(serverEP); // Объект TCP сокета сервера
        static async Task Main()
        {
            Console.WriteLine("Server is starting..");
            try
            {
                server.Start(); // Запуск сервера
            }
            catch (SocketException ex)
            {
                Console.WriteLine($"An error has occured while running the server! {ex.Message}");
            }
            Console.WriteLine("Server is started successfully!\nWaiting for connections..\n\n\n");
            while (true)
            {
                try
                {
                    using (TcpClient client = await server.AcceptTcpClientAsync()) // Объект TCP сокета подключившегося клиента
                    {
                        if (client != null)
                        {
                            Console.WriteLine($"\nNew TCP connection with client {client.GetStream()}");
                            NetworkStream stream = client.GetStream(); // Получение потока клиента

                            byte[] request = new byte[256];
                            await stream.ReadAsync(request, 0, request.Length); // Получение запроса клиента
                            Console.Write($"\nReceived a new request: {Encoding.UTF8.GetString(request).Trim()}");
                            if (Encoding.UTF8.GetString(request).Trim().Contains("Connect")) // Если от клиента пришёл запрос на подключение
                            {
                                await ConnectCommand(stream); // Запрос "Connect"
                            }
                            else if (Encoding.UTF8.GetString(request).Trim().Contains("Register")) // Если от клиента пришёл запрос на регистрацию
                            {
                                string req = Encoding.UTF8.GetString(request).Trim();
                                Console.WriteLine($"\nCommand: {Encoding.UTF8.GetString(request).Trim()}"); // Если от клиента пришёл неизвестный запрос
                                await RegisterCommand(stream, Encoding.UTF8.GetString(request).Trim()); // Запрос "Register"
                            }
                            else
                            {
                                await UnknownCommand(stream); // Неизвестный запрос
                            }
                            Console.WriteLine("\nConnection response sent to client!");
                        }
                        else
                        {
                            Console.WriteLine("\nClient disconnected!");
                            client.Dispose(); // Очистка кэша от TCP сокета отключившегося клиента
                        }
                    }
                }
                catch (SocketException ex)
                {
                    Console.WriteLine($"\nAn error has occured while client {1} was connecting to the server! {ex.Message}");
                }
            }
        }

        static private async Task ConnectCommand(NetworkStream stream) // Функция для запроса "Connect"
        {
            byte[] response = Encoding.UTF8.GetBytes("Successfull!");
            await stream.WriteAsync(response, 0, response.Length); // Отправка ответа
            response = null;
        }
        static private async Task UnknownCommand(NetworkStream stream) // Функция для неизвестного запроса
        {
            byte[] response = Encoding.UTF8.GetBytes("Unknown request!");
            await stream.WriteAsync(response, 0, response.Length); // Отправка ответа
            response = null;
        }
        static private async Task RegisterCommand(NetworkStream stream, string registrationData) // Функция для запроса "Register"
        {
            Console.WriteLine(registrationData);
            byte[] response = Encoding.UTF8.GetBytes("Registered!");
            await stream.WriteAsync(response, 0, response.Length); // Отправка ответа
            response = null;
        }
    }

    class UserData // Класс регистрационных данных человека
    {
        private string surname { get; set; } // Фамилия
        private string firstname { get; set; } // Имя
        private string patronymic { get; set; } // Отчество
        private string birthdate { get; set; } // Дата рождения
        private char gender { get; set; } // Пол
        private string password { get; set; } // Пароль

        public UserData(string surname, string firstname, string patronymic, string birthdate, char gender, string password)
        {
            this.surname = surname;
            this.firstname = firstname;
            this.patronymic = patronymic;
            this.birthdate = birthdate;
            this.gender = gender;
            this.password = password;
        }
    }
    }