﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace ATM_Source
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            LoginButton.Enabled = false;
            RegistrationButton.Enabled = false;
        }
        private async Task checkConnection() // Функция проверки соединения с сервером
        {
            try
            {
                using (TcpClient client = new TcpClient()) // TCP сокет клиента
                {
                    IPAddress serverIP = IPAddress.Parse("127.0.0.1"); // IP адрес сервеа
                    int serverPort = 30126; // Порт сервера
                    try
                    {
                        await client.ConnectAsync(serverIP, serverPort); // Подключение клиента к серверу
                        if (client.Connected)
                        {
                            Console.WriteLine("\nTCP connection with ATM Source server is set!");
                            NetworkStream stream = client.GetStream(); // Получение потока сервера
                            byte[] request = Encoding.UTF8.GetBytes("Connect"); 
                            await stream.WriteAsync(request, 0, request.Length); // Отправка запроса на подключение серверу
                            request = null;

                            byte[] received = new byte[256];
                            await stream.ReadAsync(received, 0, received.Length); // Получение ответа от сервера
                            if (Encoding.UTF8.GetString(received).Trim().Contains("Successfull!"))
                            {
                                Console.WriteLine($"\nReceived response: {Encoding.UTF8.GetString(received).Trim()}");
                                this.Invoke(new Action(() => // Если клиенту удалось подключиться к серверу
                                {
                                    serverConnectionLabel.Text = "Connected!";
                                    LoginButton.Enabled = true;
                                    RegistrationButton.Enabled = true;
                                }));
                            }
                            else
                            {
                                Console.WriteLine($"Received response: {Encoding.UTF8.GetString(received).Trim()}");
                                this.Invoke(new Action(() => // Если произошла ошибка при подключении клиента к серверу
                                {
                                    serverConnectionLabel.Text = "\nAn exception has occured while connecting!";
                                }));
                            }
                            received = null;
                        }
                        else
                        {
                            Console.WriteLine("\nThere is no TCP connection to the ATM Source server!");
                            this.Invoke(new Action(() => // Если клиенту не удалось подключиться к серверу
                            {
                                serverConnectionLabel.Text = "No connection!";
                            }));

                        }
                        client.Dispose();
                    }
                    catch (SocketException ex)
                    {
                        Console.WriteLine($"\nAn error has occured while connecting to the server!\n{ex.Message}");
                    }
                }
            }
            catch (SocketException ex)
            {
                Console.WriteLine($"\nAn error has occured while starting TCP client!\n{ex.Message}");
            }
        }
        private async void CheckConnectionButtonClick(object sender, EventArgs e)  // Функция для кнопки для проверки соединения с сервером
        {
            await checkConnection(); // Проверка соединения
        }
        private void RegistrationButtonClick(object sender, EventArgs e) // Функция для кнопки для вызова формы регистрации
        {
            RegistrationForm rf = new RegistrationForm();
            rf.Show();
        }
    }
}
