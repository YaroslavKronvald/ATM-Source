﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Source
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }
        private void RegistrationQuitButtonClick(object sender, EventArgs e) // Фунция для кнопки для выхода из формы регистрации
        {
            Close();
        }
        private void GenderInputRegRadioButtonCheckedChangedClick(object sender, EventArgs e) // Функция для кнопки для смены выбранного пола
        {
            if (GenderInputRegRadioButton1.Checked) // Для мужского пола
            {
                GenderInputRegRadioButton2.Checked = false;
                GenderInputRegRadioButton3.Checked = false;
            }
            else if (GenderInputRegRadioButton2.Checked) // Для женского пола
            {
                GenderInputRegRadioButton1.Checked = false;
                GenderInputRegRadioButton3.Checked = false;
            }
            else // Для другого пола
            {
                GenderInputRegRadioButton1.Checked = false;
                GenderInputRegRadioButton2.Checked = false;
            }
        }
        private async void RegistrationConfirmButtonClick(object sender, EventArgs e) // Функция для кнопки для подтверждения регистрации 
        {
            string firstname, surname, patronymic, password;
            MonthCalendar birthdate;
            char gender;
            firstname = SurnameInputRegTextBox.Text;
            surname = SurnameInputRegTextBox.Text;
            patronymic = PatronymicInputRegTextBox.Text;
            password = PasswordInputRegTextBox.Text;
            birthdate = BirthdayInputRegMonthCalendar;
            if (GenderInputRegRadioButton1.Checked)
            {
                gender = 'M';
            }
            else if (GenderInputRegRadioButton2.Checked)
            {
                gender = 'F';
            }
            else
            {
                gender = 'N';
            }
            UserData newUser = new UserData(surname, firstname, patronymic, birthdate, gender, password); // Создание нового экземпляра класса UserData
            using (TcpClient client = new TcpClient()) // Создание нового TCP клиента
            {
                IPAddress serverIP = IPAddress.Parse("127.0.0.1"); // IP адрес сервера
                int serverPort = 30126; // Порт сервера
                await client.ConnectAsync(serverIP, serverPort); // Подключение клиента к серверу
                NetworkStream stream = client.GetStream(); // Получение потока клиента
                await newUser.RegisterUser(stream); // Отправка регистрационных данных клиента серверу
                byte[] response = new byte[256];
                await stream.ReadAsync(response, 0, response.Length); // Получение ответа по регистрации от сервера
                RegistrationStatusTextBox.Text = Encoding.UTF8.GetString(response).Trim();
                stream.Dispose(); // Очистка памяти от потока клиента
                client.Dispose(); // Очистка памяти от TCP сокета клиента
            }
        }
    }
    class UserData // Класс регистрационных данных человека
    {
        private string surname { get; set; } // Фамилия
        private string firstname { get; set; } // Имя
        private string patronymic { get; set; } // Отчество
        private MonthCalendar birthdate { get; set; } // Дата рождения
        private char gender { get; set; } // Пол
        private string password { get; set; } // Пароль

        public UserData(string surname, string firstname, string patronymic, MonthCalendar birthdate, char gender, string password)
        {
            this.surname = surname;
            this.firstname = firstname;
            this.patronymic = patronymic;
            this.birthdate = birthdate;
            this.gender = gender;
            this.password = password;
        }

        private string PrepareUserData(string surname, string firstname, string patronymic, MonthCalendar birthdate, char gender, string password) // Функция для подготовки строки данных для регистрации
        {
            string result = surname + '_' + firstname + "_" + patronymic + "_" + birthdate.SelectionStart.ToString() + '_' + gender + '_' + password;
            return result;
        }
        public async Task RegisterUser(NetworkStream stream) // Функция для регистрации нового пользователя
        {
            string registrationString = "Register+" + PrepareUserData(surname, firstname, patronymic, birthdate, gender, password); // Строка данных для регистрации
            await stream.WriteAsync(Encoding.UTF8.GetBytes(registrationString), 0, registrationString.Length); // Отправка запроса на регистрацию нового пользователя серверу
        }
    }
}