﻿namespace ATM_Source
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SurnameInputRegTextBox = new System.Windows.Forms.TextBox();
            this.FirstNameInputRegTextBox = new System.Windows.Forms.TextBox();
            this.PatronymicInputRegTextBox = new System.Windows.Forms.TextBox();
            this.BirthdayInputRegMonthCalendar = new System.Windows.Forms.MonthCalendar();
            this.GenderInputRegRadioButton1 = new System.Windows.Forms.RadioButton();
            this.GenderInputRegRadioButton2 = new System.Windows.Forms.RadioButton();
            this.GenderInputRegRadioButton3 = new System.Windows.Forms.RadioButton();
            this.RegistrationQuitButton = new System.Windows.Forms.Button();
            this.RegistrationConfirmButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.PasswordInputRegTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.RegistrationStatusTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // SurnameInputRegTextBox
            // 
            this.SurnameInputRegTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.SurnameInputRegTextBox.Location = new System.Drawing.Point(12, 42);
            this.SurnameInputRegTextBox.Name = "SurnameInputRegTextBox";
            this.SurnameInputRegTextBox.Size = new System.Drawing.Size(430, 35);
            this.SurnameInputRegTextBox.TabIndex = 0;
            // 
            // FirstNameInputRegTextBox
            // 
            this.FirstNameInputRegTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.FirstNameInputRegTextBox.Location = new System.Drawing.Point(12, 102);
            this.FirstNameInputRegTextBox.Name = "FirstNameInputRegTextBox";
            this.FirstNameInputRegTextBox.Size = new System.Drawing.Size(430, 35);
            this.FirstNameInputRegTextBox.TabIndex = 1;
            // 
            // PatronymicInputRegTextBox
            // 
            this.PatronymicInputRegTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.PatronymicInputRegTextBox.Location = new System.Drawing.Point(12, 162);
            this.PatronymicInputRegTextBox.Name = "PatronymicInputRegTextBox";
            this.PatronymicInputRegTextBox.Size = new System.Drawing.Size(430, 35);
            this.PatronymicInputRegTextBox.TabIndex = 2;
            // 
            // BirthdayInputRegMonthCalendar
            // 
            this.BirthdayInputRegMonthCalendar.Location = new System.Drawing.Point(12, 240);
            this.BirthdayInputRegMonthCalendar.Name = "BirthdayInputRegMonthCalendar";
            this.BirthdayInputRegMonthCalendar.TabIndex = 3;
            // 
            // GenderInputRegRadioButton1
            // 
            this.GenderInputRegRadioButton1.AutoSize = true;
            this.GenderInputRegRadioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.GenderInputRegRadioButton1.Location = new System.Drawing.Point(268, 240);
            this.GenderInputRegRadioButton1.Name = "GenderInputRegRadioButton1";
            this.GenderInputRegRadioButton1.Size = new System.Drawing.Size(63, 24);
            this.GenderInputRegRadioButton1.TabIndex = 4;
            this.GenderInputRegRadioButton1.TabStop = true;
            this.GenderInputRegRadioButton1.Text = "Male";
            this.GenderInputRegRadioButton1.UseVisualStyleBackColor = true;
            this.GenderInputRegRadioButton1.CheckedChanged += new System.EventHandler(this.GenderInputRegRadioButtonCheckedChangedClick);
            // 
            // GenderInputRegRadioButton2
            // 
            this.GenderInputRegRadioButton2.AutoSize = true;
            this.GenderInputRegRadioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GenderInputRegRadioButton2.Location = new System.Drawing.Point(268, 270);
            this.GenderInputRegRadioButton2.Name = "GenderInputRegRadioButton2";
            this.GenderInputRegRadioButton2.Size = new System.Drawing.Size(80, 24);
            this.GenderInputRegRadioButton2.TabIndex = 5;
            this.GenderInputRegRadioButton2.TabStop = true;
            this.GenderInputRegRadioButton2.Text = "Female";
            this.GenderInputRegRadioButton2.UseVisualStyleBackColor = true;
            this.GenderInputRegRadioButton2.CheckedChanged += new System.EventHandler(this.GenderInputRegRadioButtonCheckedChangedClick);
            // 
            // GenderInputRegRadioButton3
            // 
            this.GenderInputRegRadioButton3.AutoSize = true;
            this.GenderInputRegRadioButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GenderInputRegRadioButton3.Location = new System.Drawing.Point(268, 300);
            this.GenderInputRegRadioButton3.Name = "GenderInputRegRadioButton3";
            this.GenderInputRegRadioButton3.Size = new System.Drawing.Size(101, 24);
            this.GenderInputRegRadioButton3.TabIndex = 6;
            this.GenderInputRegRadioButton3.TabStop = true;
            this.GenderInputRegRadioButton3.Text = "Not stated";
            this.GenderInputRegRadioButton3.UseVisualStyleBackColor = true;
            this.GenderInputRegRadioButton3.CheckedChanged += new System.EventHandler(this.GenderInputRegRadioButtonCheckedChangedClick);
            // 
            // RegistrationQuitButton
            // 
            this.RegistrationQuitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegistrationQuitButton.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.RegistrationQuitButton.Location = new System.Drawing.Point(12, 530);
            this.RegistrationQuitButton.Name = "RegistrationQuitButton";
            this.RegistrationQuitButton.Size = new System.Drawing.Size(125, 59);
            this.RegistrationQuitButton.TabIndex = 7;
            this.RegistrationQuitButton.Text = "Quit";
            this.RegistrationQuitButton.UseVisualStyleBackColor = true;
            this.RegistrationQuitButton.Click += new System.EventHandler(this.RegistrationQuitButtonClick);
            // 
            // RegistrationConfirmButton
            // 
            this.RegistrationConfirmButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegistrationConfirmButton.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.RegistrationConfirmButton.Location = new System.Drawing.Point(268, 449);
            this.RegistrationConfirmButton.Name = "RegistrationConfirmButton";
            this.RegistrationConfirmButton.Size = new System.Drawing.Size(184, 140);
            this.RegistrationConfirmButton.TabIndex = 8;
            this.RegistrationConfirmButton.Text = "Confirm";
            this.RegistrationConfirmButton.UseVisualStyleBackColor = true;
            this.RegistrationConfirmButton.Click += new System.EventHandler(this.RegistrationConfirmButtonClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "1) Surname";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 24);
            this.label2.TabIndex = 10;
            this.label2.Text = "2) First name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(12, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 24);
            this.label3.TabIndex = 11;
            this.label3.Text = "3) Patronymic";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(12, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 25);
            this.label4.TabIndex = 12;
            this.label4.Text = "4) Birthday";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(263, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 25);
            this.label5.TabIndex = 13;
            this.label5.Text = "5) Gender";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(264, 340);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 24);
            this.label6.TabIndex = 14;
            this.label6.Text = "6) Password";
            // 
            // PasswordInputRegTextBox
            // 
            this.PasswordInputRegTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.PasswordInputRegTextBox.Location = new System.Drawing.Point(268, 367);
            this.PasswordInputRegTextBox.Name = "PasswordInputRegTextBox";
            this.PasswordInputRegTextBox.Size = new System.Drawing.Size(174, 35);
            this.PasswordInputRegTextBox.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.25F);
            this.label7.Location = new System.Drawing.Point(8, 425);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(138, 44);
            this.label7.TabIndex = 16;
            this.label7.Text = "Status:";
            // 
            // RegistrationStatusTextBox
            // 
            this.RegistrationStatusTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.RegistrationStatusTextBox.Location = new System.Drawing.Point(17, 472);
            this.RegistrationStatusTextBox.Name = "RegistrationStatusTextBox";
            this.RegistrationStatusTextBox.ReadOnly = true;
            this.RegistrationStatusTextBox.Size = new System.Drawing.Size(164, 35);
            this.RegistrationStatusTextBox.TabIndex = 17;
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 601);
            this.Controls.Add(this.RegistrationStatusTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.PasswordInputRegTextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RegistrationConfirmButton);
            this.Controls.Add(this.RegistrationQuitButton);
            this.Controls.Add(this.GenderInputRegRadioButton3);
            this.Controls.Add(this.GenderInputRegRadioButton2);
            this.Controls.Add(this.GenderInputRegRadioButton1);
            this.Controls.Add(this.BirthdayInputRegMonthCalendar);
            this.Controls.Add(this.PatronymicInputRegTextBox);
            this.Controls.Add(this.FirstNameInputRegTextBox);
            this.Controls.Add(this.SurnameInputRegTextBox);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RegistrationForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "User Registration Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox SurnameInputRegTextBox;
        private System.Windows.Forms.TextBox FirstNameInputRegTextBox;
        private System.Windows.Forms.TextBox PatronymicInputRegTextBox;
        private System.Windows.Forms.MonthCalendar BirthdayInputRegMonthCalendar;
        private System.Windows.Forms.RadioButton GenderInputRegRadioButton1;
        private System.Windows.Forms.RadioButton GenderInputRegRadioButton2;
        private System.Windows.Forms.RadioButton GenderInputRegRadioButton3;
        private System.Windows.Forms.Button RegistrationQuitButton;
        private System.Windows.Forms.Button RegistrationConfirmButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox PasswordInputRegTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox RegistrationStatusTextBox;
    }
}