﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace ATM_Source
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            LoginButton.Enabled = false;
            RegistrationButton.Enabled = false;
        }
        private async Task checkConnection()
        {
            try
            {
                using (TcpClient client = new TcpClient())
                {
                    IPAddress serverIP = IPAddress.Parse("127.0.0.1");
                    int serverPort = 30126;
                    try
                    {
                        await client.ConnectAsync(serverIP, serverPort);
                        if (client.Connected)
                        {
                            Console.WriteLine("TCP connection with ATM Source server is set!");
                            NetworkStream stream = client.GetStream();
                            byte[] request = Encoding.UTF8.GetBytes("Connect");
                            await stream.WriteAsync(request, 0, request.Length);
                            request = null;

                            byte[] received = new byte[256];
                            await stream.ReadAsync(received, 0, received.Length);
                            if (Encoding.UTF8.GetString(received).Trim().Contains("Successfull!"))
                            {
                                Console.WriteLine($"Received response: {Encoding.UTF8.GetString(received).Trim()}");
                                this.Invoke(new Action(() =>
                                {
                                    serverConnectionLabel.Text = "Connected!";
                                    LoginButton.Enabled = true;
                                    RegistrationButton.Enabled = true;
                                }));
                            }
                            else
                            {
                                Console.WriteLine($"Received response: {Encoding.UTF8.GetString(received).Trim()}");
                                this.Invoke(new Action(() =>
                                {
                                    serverConnectionLabel.Text = "An exception while connecting!";
                                }));
                            }
                            received = null;
                        }
                        else
                        {
                            Console.WriteLine("There is no TCP connection to the ATM Source server!");
                            this.Invoke(new Action(() =>
                            {
                                serverConnectionLabel.Text = "No connection!";
                            }));

                        }
                    }
                    catch (SocketException ex)
                    {
                        Console.WriteLine("An error has occured while connecting to the server!");
                    }
                }
            }
            catch (SocketException ex)
            {
                Console.WriteLine("An error has occured while starting TCP client!");
            }
        }
        private async void CheckConnectionButtonClick(object sender, EventArgs e)
        {
            await checkConnection();
        }
        private void RegistrationButtonClick(object sender, EventArgs e)
        {
            RegistrationForm rf = new RegistrationForm();
            rf.Show();
        }
    }
}
