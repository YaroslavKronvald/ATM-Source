﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Source
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }
        private void RegistrationQuitButtonClick(object sender, EventArgs e)
        {
            Close();
        }
    }
    class HumanData
    {
        private string surname { get; set; }
        private string firstname { get; set; }
        private string patronymic { get; set; }
        private MonthCalendar birthdate { get; set; }
        private char gender { get; set; }
        private string password { get; set; }

        public HumanData(string surname, string firstname, string patronymic, MonthCalendar birthdate, char gender, string password)
        {
            this.surname = surname;
            this.firstname = firstname;
            this.patronymic = patronymic;
            this.birthdate = birthdate;
            this.gender = gender;
            this.password = password;
        }
    }
}
