﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Source
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }
        private void RegistrationQuitButtonClick(object sender, EventArgs e) // Фунция для кнопки для выхода из формы регистрации
        {
            Close();
        }
    }
    class UserData // Класс регистрационных данных человека
    {
        private string surname { get; set; } // Фамилия
        private string firstname { get; set; } // Имя
        private string patronymic { get; set; } // Отчество
        private MonthCalendar birthdate { get; set; } // Дата рождения
        private char gender { get; set; } // Пол
        private string password { get; set; } // Пароль

        public UserData(string surname, string firstname, string patronymic, MonthCalendar birthdate, char gender, string password)
        {
            this.surname = surname;
            this.firstname = firstname;
            this.patronymic = patronymic;
            this.birthdate = birthdate;
            this.gender = gender;
            this.password = password;
        }

        private string PrepareUserData(string surname, string firstname, string patronymic, MonthCalendar birthdate, char gender, string password) // Функция для подготовки строки данных для регистрации
        {
            string result = surname + '_' + firstname + "_" + patronymic + "_" + birthdate.ToString() + '_' + gender + '_' + password;
            return result;
        }
        public async Task RegisterUser() // Функция для регистрации нового пользователя
        {
            using (TcpClient client = new TcpClient()) // Создание TCP сокета для клиента
            {
                IPAddress serverIP = IPAddress.Parse("127.0.0.1"); // IP адрес сервера
                int serverPort = 30126; // Порт сервера
                await client.ConnectAsync(serverIP, serverPort); // Подключение клиента к серверу
                NetworkStream stream = client.GetStream(); // Получение потока клиента
                string registrationString = "Register+" + PrepareUserData(surname, firstname, patronymic, birthdate, gender, password); // Строка данных для регистрации
                await stream.WriteAsync(Encoding.UTF8.GetBytes(registrationString), 0, registrationString.Length); // Отправка запроса на регистрацию нового пользователя серверу
                stream.Dispose(); // Очистка памяти от потока клиента
                client.Dispose(); // Очистка памяти от TCP сокета клиента
            }
        }
    }
}
