﻿namespace ATM_Source
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.RegistrationButton = new System.Windows.Forms.Button();
            this.LoginButton = new System.Windows.Forms.Button();
            this.MainWelcomeLabel = new System.Windows.Forms.Label();
            this.serverConnectionLabel = new System.Windows.Forms.Label();
            this.CheckConnectionButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RegistrationButton
            // 
            this.RegistrationButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegistrationButton.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.RegistrationButton.Location = new System.Drawing.Point(60, 345);
            this.RegistrationButton.Name = "RegistrationButton";
            this.RegistrationButton.Size = new System.Drawing.Size(344, 94);
            this.RegistrationButton.TabIndex = 0;
            this.RegistrationButton.Text = "Registration";
            this.RegistrationButton.UseVisualStyleBackColor = true;
            this.RegistrationButton.Click += new System.EventHandler(this.RegistrationButtonClick);
            // 
            // LoginButton
            // 
            this.LoginButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 29.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LoginButton.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.LoginButton.Location = new System.Drawing.Point(60, 216);
            this.LoginButton.Name = "LoginButton";
            this.LoginButton.Size = new System.Drawing.Size(344, 94);
            this.LoginButton.TabIndex = 1;
            this.LoginButton.Text = "Login";
            this.LoginButton.UseVisualStyleBackColor = true;
            // 
            // MainWelcomeLabel
            // 
            this.MainWelcomeLabel.AutoSize = true;
            this.MainWelcomeLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MainWelcomeLabel.Font = new System.Drawing.Font("Franklin Gothic Medium", 38.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainWelcomeLabel.Location = new System.Drawing.Point(155, 75);
            this.MainWelcomeLabel.Name = "MainWelcomeLabel";
            this.MainWelcomeLabel.Size = new System.Drawing.Size(159, 65);
            this.MainWelcomeLabel.TabIndex = 2;
            this.MainWelcomeLabel.Text = "Hello!";
            // 
            // serverConnectionLabel
            // 
            this.serverConnectionLabel.AutoSize = true;
            this.serverConnectionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.serverConnectionLabel.Location = new System.Drawing.Point(161, 140);
            this.serverConnectionLabel.Name = "serverConnectionLabel";
            this.serverConnectionLabel.Size = new System.Drawing.Size(182, 29);
            this.serverConnectionLabel.TabIndex = 3;
            this.serverConnectionLabel.Text = "No connection!";
            // 
            // CheckConnectionButton
            // 
            this.CheckConnectionButton.Font = new System.Drawing.Font("Sitka Small", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CheckConnectionButton.Location = new System.Drawing.Point(12, 12);
            this.CheckConnectionButton.Name = "CheckConnectionButton";
            this.CheckConnectionButton.Size = new System.Drawing.Size(107, 46);
            this.CheckConnectionButton.TabIndex = 4;
            this.CheckConnectionButton.Text = "Check connection";
            this.CheckConnectionButton.UseVisualStyleBackColor = true;
            this.CheckConnectionButton.Click += new System.EventHandler(this.CheckConnectionButtonClick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 601);
            this.Controls.Add(this.CheckConnectionButton);
            this.Controls.Add(this.serverConnectionLabel);
            this.Controls.Add(this.MainWelcomeLabel);
            this.Controls.Add(this.LoginButton);
            this.Controls.Add(this.RegistrationButton);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ATM Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button RegistrationButton;
        private System.Windows.Forms.Button LoginButton;
        private System.Windows.Forms.Label MainWelcomeLabel;
        private System.Windows.Forms.Label serverConnectionLabel;
        private System.Windows.Forms.Button CheckConnectionButton;
    }
}

